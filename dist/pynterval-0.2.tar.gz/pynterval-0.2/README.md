# pynterval

A small python module to handle numeric intervals


